package com.test.dao;
import org.springframework.data.jpa.repository.JpaRepository;

import com.test.model.employee; 

public interface employeeDAO extends JpaRepository<employee , Integer> {

	
	
}
