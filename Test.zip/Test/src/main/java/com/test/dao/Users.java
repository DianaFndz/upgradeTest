package com.test.dao;
import org.springframework.data.jpa.repository.JpaRepository;

import com.test.model.profile; 

public interface Users extends JpaRepository<profile , Integer> {

	
	
}
