package com.test.dao;
import org.springframework.data.jpa.repository.JpaRepository;

import com.test.model.profile; 

public interface profileDAO extends JpaRepository<profile , Integer> {

	
	
}
