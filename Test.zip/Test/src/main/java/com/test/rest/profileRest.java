package com.test.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import com.test.dao.profileDAO;
import com.test.model.profile;

import antlr.collections.List;
@RestController
@RequestMapping("profile")
public class profileRest {
	@Autowired
	private profileDAO personaDAO;
	
	@PostMapping("/saveProfile")
	public void saveProfile(@RequestBody profile profile) {
		personaDAO.save(profile);
		
	}
	
	@DeleteMapping("/eliminar/{idProfile}"){
		public void deleteP(@PathVariable("idProfile") Integer idProfile) {
			profileDAO.deleteById(idProfile);
		}
	}
	
	@GetMapping("/listed")
	public List<profile>listed() {
		return (List) profileDAO.findAll();
		
	}
	
	

}
