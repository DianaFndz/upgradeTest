package com.test.model;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class employee {
	@Id
	private Integer idEmployee;
	@Column
	private String Nombre;
	

}
